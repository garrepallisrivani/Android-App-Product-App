package com.kotlinpractice.productapp.ui

import ProductAdapter
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.kotlinpractice.productapp.R
import com.kotlinpractice.productapp.databinding.FragmentProductListBinding
import com.kotlinpractice.productapp.viewmodel.ProductViewModel
import com.kotlinpractice.productapp.utils.saveLastScreen

class ProductListFragment : Fragment() {

    private lateinit var binding: FragmentProductListBinding
    private val viewModel: ProductViewModel by activityViewModels()
    private lateinit var adapter: ProductAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentProductListBinding.inflate(inflater, container, false).also { binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        (activity as AppCompatActivity).setSupportActionBar(binding.toolbar)
        binding.toolbar.title = getString(R.string.product_list)
        binding.toolbar.setTitleTextColor(resources.getColor(android.R.color.white))


        adapter = ProductAdapter { product ->
            // Navigate to ProductDetailFragment
            findNavController().navigate(
                R.id.productDetailsFragment,
                bundleOf("productId" to product.id)
            )
        }



        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = LinearLayoutManager(requireContext())


        viewModel.products.observe(viewLifecycleOwner) { productList ->
            adapter.submitList(productList) // submitList works with ListAdapter
        }


        viewModel.fetchProducts()
    }
    override fun onResume() {
        super.onResume()
        // Save when list screen becomes visible again
        requireContext().saveLastScreen("list", -1)
    }
}
