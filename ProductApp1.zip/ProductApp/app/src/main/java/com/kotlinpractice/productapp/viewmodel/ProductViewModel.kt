package com.kotlinpractice.productapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kotlinpractice.productapp.data.model.Product
import com.kotlinpractice.productapp.data.repository.ProductRepository
import kotlinx.coroutines.launch

class ProductViewModel: ViewModel() {
    private val repository = ProductRepository()

    val products = MutableLiveData<List<Product>>()
    val selectedProduct = MutableLiveData<Product>()

    fun fetchProducts() {
        viewModelScope.launch {
            try {
                val result = repository.getProducts()
                products.postValue(result)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun fetchProductDetail(id: Int) {
        viewModelScope.launch {
            try {
                val product = repository.getProductDetail(id)
                selectedProduct.postValue(product)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}