package com.kotlinpractice.productapp.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import coil.load
import com.kotlinpractice.productapp.databinding.FragmentProductDetailsBinding
import com.kotlinpractice.productapp.utils.saveLastScreen
import com.kotlinpractice.productapp.viewmodel.ProductViewModel

class ProductDetailsFragment : Fragment() {

    private lateinit var binding: FragmentProductDetailsBinding
    private val viewModel: ProductViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ) = FragmentProductDetailsBinding.inflate(inflater, container, false).also { binding = it }.root

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val productId = arguments?.getInt("productId") ?: return
        requireContext().saveLastScreen("detail", productId)
        (activity as? AppCompatActivity)?.setSupportActionBar(binding.toolbar)
        binding.toolbar.title = "Product Details"
        binding.toolbar.setTitleTextColor(resources.getColor(android.R.color.white))
        binding.toolbar.setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
        binding.toolbar.setNavigationOnClickListener {
            requireActivity().onBackPressed()
        }

        viewModel.fetchProductDetail(productId)

        viewModel.selectedProduct.observe(viewLifecycleOwner) { product ->
            binding.productTitle.text = product.title
            binding.productCategory.text="Category: ${product.category}"
            binding.productPrice.text = "₹${product.price}"
            binding.productDesc.text = product.description
            binding.productImage.load(product.image)
        }
    }
}