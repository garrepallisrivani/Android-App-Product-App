package com.kotlinpractice.productapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.navigation.NavController
import com.kotlinpractice.productapp.R

import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.kotlinpractice.productapp.databinding.ActivityMainBinding
import com.kotlinpractice.productapp.utils.getLastScreen

class MainActivity : AppCompatActivity() {
   lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navHostFragment=supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment

        val navController=navHostFragment.navController

        val (screen, productId) = this.getLastScreen()
        binding.root.post {
            if (screen == "detail" && productId != -1) {
                navController.navigate(
                    R.id.productDetailsFragment,
                    bundleOf("productId" to productId)
                )
            }
        }
    }
}
