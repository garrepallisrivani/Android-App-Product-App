package com.kotlinpractice.productapp.data.repository

import com.kotlinpractice.productapp.data.network.RetrofitInstance

class ProductRepository {
    private val api = RetrofitInstance.api

    suspend fun getProducts() = api.getProducts()
    suspend fun getProductDetail(id: Int) = api.getProductDetail(id)
}